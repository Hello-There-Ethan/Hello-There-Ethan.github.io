console.log("hello world");

function abilityRyan() {
  console.log("Longlive the Fatherland, Longlive the MOtherland, Long live the confederacy, long live the brotherland");
};
// const button = document.getElementById("button");

// const interval = setInterval(function () {
//   console.log("Click me!");
// }, 1000);

// setTimeout(function () {
//   clearInterval(interval);
// }, 5000);

const button = document.getElementById("button");

setTimeout(function () {
  button.style.backgroundColor = "lightblue";
  button.style.visibility = "hidden";
}, 2000);

// var element = document.getElementById('UsaBall');
// element.style.opacity = "0";
// element.style.filter  = 'alpha(opacity=90)'; // IE fallback

const x = 10;

if (x < 10){
  console.log("x less than 10");
} else if ((x > 10) || (x==10)) {
  console.log("x is greater than or equal to 10");
} else {
  console.log("x is weird");
}
