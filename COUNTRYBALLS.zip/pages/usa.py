from flask import Flask, render_template
import time
app = Flask(__name__)
@app.route("/")

def index():
  return render_template("index.html")
app.run(debug=True, host = "0.0.0.0", port = 8080)
  x = input("What is my Name?")
  if x ==("USA") or x == ("United States of America"):
    print("You caught this countryball!")
    time.sleep(1)
    print("Here are some intresting Facts : 1. The Usa is the First country to gain independence from a European power 2. The USA flag was designed by a high school student - Robert G. Heft 3. Since it’s debut, it has had 27 different version 4. It has the world largest GDP, second largest PPP, and the third most population 5. USA also has the strongest Air Force and Navy 6. The USA is the home of the Eagles, Redskins, 49ers, Pats, and Bills")
    time.sleep(5)
    print("Here are the stats : ❤️2860 Health ⚔️1194 Attack")